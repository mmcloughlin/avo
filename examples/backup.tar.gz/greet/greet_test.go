package greet

import (
	"os"
	"testing"
)

//go:generate go run asm.go -out greet.s -stubs stub.go

func TestGreet(t *testing.T) {
	errno := greet(os.Stdout.Fd())
	t.Log(errno)
}
