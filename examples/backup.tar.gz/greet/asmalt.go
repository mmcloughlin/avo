// +build avo

package main

import (
	. "github.com/mmcloughlin/avo/build"
	"github.com/mmcloughlin/avo/operand"
	"github.com/mmcloughlin/avo/reg"
)

func main() {
	msg := GLOBL("msg", RODATA|NOPTR)
	DATA(0, operand.String("helloavo"))

	TEXT("greet", NOSPLIT, "func(fd uintptr) uintptr")

	Load(Param("fd"), reg.RDI)
	LEAQ(msg, reg.RSI)
	MOVQ(operand.U64(8), reg.RDX)
	MOVQ(operand.U64(0), reg.R8)
	MOVQ(operand.U64(0), reg.R9)
	MOVQ(operand.U64(0), reg.R10)

	MOVQ(operand.U32(0x2000004), reg.RAX)
	SYSCALL()

	Store(reg.RAX, ReturnIndex(0))

	RET()

	Generate()
}
