// +build ignore

package main

import (
	. "github.com/mmcloughlin/avo/build"
	"github.com/mmcloughlin/avo/reg"
)

func main() {
	TEXT("Add", NOSPLIT, "func(x, y uint64) uint64")
	ADDQ(reg.RAX, reg.EBX)
	Generate()
}
